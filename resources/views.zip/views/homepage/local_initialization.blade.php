<head>
    <!--libraries initializations-->
    <link href="{{ asset('css/cs-homepage.css') }}" rel="stylesheet" />

</head>
