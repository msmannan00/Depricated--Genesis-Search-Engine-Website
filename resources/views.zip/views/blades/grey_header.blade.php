<div class="grey-header">
    <img src="{{constant::$logo_small}}" class="grey-header__logo disable-highlight" alt="" onclick="location.href='./'" />
    <p class="grey-header__catagories-container disable-highlight">
        <span ><a href="https://protonmail.com/tor" class="light_header__catagory">Proton mail</a></span>
    </p>
</div>
