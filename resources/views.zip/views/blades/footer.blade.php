<div class="footer-bar disable-highlight">
    <!--footer first line-->
    <footer class="footer-bar__content">
        <p class="footer-bar__text-top">Pakistan</p>
    </footer>

    <!--footer second line-->
    <footer class="footer-bar__content disable-highlight">
        <div class="footer-bar__text-bottom">
            <span class="footer-bar__catagories">Business</span>
            <span class="footer-bar__catagories footer-bar__catagories--bottom-spacing"><a href="http://localhost/BoogleSearch/public/about" style="color: #767676"> About</a></span>
            <a href="http://localhost/BoogleSearch/public/reportus" class="footer-bar__catagories footer-bar__catagories--bottom-spacing" style="color: #767676">Report</a>
        </div>
    </footer>
</div>
