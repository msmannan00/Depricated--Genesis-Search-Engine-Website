<div class="notice-header">
    <div class="notice-header__message">{{$notice}}</div>
</div>
