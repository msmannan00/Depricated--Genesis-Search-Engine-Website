<p class="light_header disable-highlight">
    <span ><a href="https://protonmail.com/tor" class="light_header__catagory">Proton mail</a></span>
    <span ><a href="http://localhost/BoogleSearch/public/search?q=random&p_num=1&s_type=image" class="light_header__catagory">Images</a></span>
</p>
