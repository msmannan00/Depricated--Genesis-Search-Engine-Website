<head>
    <!--libraries initializations-->
    <link href="{{ asset('css/cs-torpage.css') }}" rel="stylesheet" />

</head>
