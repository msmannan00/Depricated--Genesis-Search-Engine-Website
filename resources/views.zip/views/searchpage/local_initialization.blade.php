<head>
    <!--libraries initializations-->
    <link href="{{ asset('css/cs-searchpage.css') }}" rel="stylesheet" />

</head>

