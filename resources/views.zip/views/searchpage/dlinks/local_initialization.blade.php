<head>
    <!--libraries initializations-->
    <link href="{{ asset('css/cs-dlink.css') }}" rel="stylesheet" />

</head>

