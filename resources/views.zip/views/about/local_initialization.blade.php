<head>
    <!--libraries initializations-->
    <link href="{{ asset('css/cs-about.css') }}" rel="stylesheet" />

</head>
